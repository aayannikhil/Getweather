from setuptools import setup

setup(
    name='cloudsek-weather-app',
    version='0.1',
    scripts=['app']
)
